# iA-Fonts

The iA Writer fonts comes bundled with [iA Writer for for Android, Windows, Mac, iPadOS and iOS](https://ia.net/writer/)

For in depth explanation of iA Writer Mono, Duo, and Quattro please read our [blog entry on Duospace](http://ia.net/topics/in-search-of-the-perfect-writing-font/) and on [iA Writer Mono, Duo, and Quattro](https://ia.net/topics/a-typographic-christmas)

This is a modification of IBM's Plex font. 
The upstream project is [here](https://github.com/IBM/type)
Please read the licensing file before working with it. 

If you fork or use our fonts, please reference iA Writer clearly. Use them creatively.

**Don't be a copycat.** With or without the fonts, do not clone our products or our website. Selling our work under your name is blatantly disrespectful and criminal. Distributing knockoffs of our work for free doesn't make you Robin Hood either. We do not approve of free plugins or themes for other apps and other counterfeits that imitate our products. They're poor quality, they undermine our business, and they openly violate our copyright. Due to their poor quality, they tarnish our reputation. They're unethical, illegal, and lame. 
